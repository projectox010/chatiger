module.exports = class Orderbook {
  constructor(asks, bids) {
    this.asks = asks;
    this.bids = bids;
  }
};

module.exports = class StopLoss {
  constructor(target) {
    this.target = target;
  }
};

module.exports = class SingleTarget {
  constructor(target) {
    this.target = target;
  }
};

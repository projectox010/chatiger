module.exports = class Ticker {
  constructor(lookbacks) {
    this.time = lookbacks;
  }
};

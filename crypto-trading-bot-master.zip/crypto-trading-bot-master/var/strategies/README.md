# Strategy folder

Put in your custom strategies here

see `modules/strategy/strategies` for examples